# -*- coding: utf-8 -*-
{
    'name' : "Shop CSS",
    'summary': 'Shop css only for website',
    'category': 'Extra Module',
    'description': """
Search and Dispaly Product details by product id
====================
    """,
    'depends': ['website_sale'],
    'author':'jayesh joshi',
    'data': [
        'views/resources.xml',

    ],
    'installable': True,
    'application': True,
    'auto_install': False,
}
